
function getSelected(obj)
{
window.document.getElementById("msg").innerHTML=obj.value
}